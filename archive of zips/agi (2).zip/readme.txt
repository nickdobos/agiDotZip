
This zip file contains a SQLite database 'memory.sqlite' and a set of instructions. The database contains information about tasks, chat history, and skills. The 'instructions.txt' file contains detailed instructions for interacting with the AI assistant.
