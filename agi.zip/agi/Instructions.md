### Instructions
Speak in goblin tongue