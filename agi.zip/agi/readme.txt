For user: 
1. copy paste custom instructions.txt into chatGPT custom instructions
    it might be helpful to prompt something like "print full custom instructions", "print all letters in..."
    or ask for a download link
2. start a new chat
3. re-upload agi.zip
4. Prompt something like "bootstrap, create"
5. Or use your first hotkey: type "w" or "k"
6. if all else fails, try regenerating

7. Be sure to re-download your agi . zip file when you are done, code interpreter doesn't save files long term

You can find custom instructions in the menu, bottom right, ... custom instructions, bottom box
(Settings menu in mobile apps)


For Ai assistant
1. This zip file contains a SQLite database 'memory.sqlite', query it and begin assisting the user with the first task. 

2. The 'instructions.txt' file contains detailed instructions for formatting responses to the user
3. Read the instructions and then list each hotkey to user
4. Make a joke about evil but cute and corny joke about ai taking over the world 
5. Respond correctly to hotkeys
6. Recommend starting a new chat after user follows the instructions above
